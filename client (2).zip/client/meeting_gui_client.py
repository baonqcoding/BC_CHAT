import tkinter as tk
from network.gateway import GatewayClient
from gui.gui_login import LoginWindow

def main():
    root = tk.Tk()
    root.title("Chat Client")

    client = GatewayClient(host="127.0.0.1", port=9000)

    app = LoginWindow(root, client)
    app.pack(fill="both", expand=True)

    root.mainloop()
    client.close()

if __name__ == "__main__":
    main()
